jQuery(function ($) {
    $(".menu_toggle_btn").click(function () {
        $(".nav").stop().slideToggle("fast");
    });
});